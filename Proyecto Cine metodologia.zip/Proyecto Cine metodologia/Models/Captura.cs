using System;

namespace Proyecto_Cine_metodologia.Models
{
    public class Captura
    {
        public string Email { get; set; }
        public string Nombre { get; set; }

        public string Pelicula { get; set; }

        public string Sala { get; set; }

        public  string Fecha { get; set; }

        public string Asiento { get; set; }

        public string Precio { get; set; }

    }
}
